
# code 4: Train RF classifier on raw features 
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, matthews_corrcoef

# Load the normalized features and labels
data = pd.read_csv("/content/normalized_features_min_max (NPInter 10412).csv", header=None)
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

# 5-fold cross-validation setup
kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
accuracy_scores, precision_scores, recall_scores, f1_scores, roc_auc_scores, specificity_scores, mcc_scores = [], [], [], [], [], [], []

for train_index, test_index in kf.split(X, y):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # Train Random Forest on raw features
    rf_raw = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_raw.fit(X_train, y_train)
    rf_raw_preds = rf_raw.predict(X_test)
    rf_raw_probs = rf_raw.predict_proba(X_test)[:, 1]  # Use probabilities for the positive class

    # Evaluate the model
    accuracy_scores.append(accuracy_score(y_test, rf_raw_preds))
    precision_scores.append(precision_score(y_test, rf_raw_preds))
    recall_scores.append(recall_score(y_test, rf_raw_preds))
    f1_scores.append(f1_score(y_test, rf_raw_preds))
    roc_auc_scores.append(roc_auc_score(y_test, rf_raw_probs))  # Use probabilities for AUC calculation

    tn, fp, fn, tp = confusion_matrix(y_test, rf_raw_preds).ravel()
    specificity = tn / (tn + fp)
    specificity_scores.append(specificity)
    mcc_scores.append(matthews_corrcoef(y_test, rf_raw_preds))

# Print average scores
print(f"Average Accuracy: {np.mean(accuracy_scores)}")
print(f"Average Precision: {np.mean(precision_scores)}")
print(f"Average Recall: {np.mean(recall_scores)}")
print(f"Average F1 Score: {np.mean(f1_scores)}")
print(f"Average ROC AUC: {np.mean(roc_auc_scores)}")
print(f"Average Specificity: {np.mean(specificity_scores)}")
print(f"Average MCC: {np.mean(mcc_scores)}")

