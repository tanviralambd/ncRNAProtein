
# Code 1: Extract conjoint triad (3-mer) from protein sequences and 4-mer frequency from RNA sequences. (Note: The protein sequence is reduced to 7-letter alphabet).

#!pip install biopython
import pandas as pd
from Bio import SeqIO
from collections import defaultdict
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# Load FASTA Files
def load_fasta(file_path):
    sequences = {}
    for record in SeqIO.parse(file_path, "fasta"):
        sequences[record.id] = str(record.seq)
    return sequences

# Load RNA and Protein sequences
rna_sequences = load_fasta("/content/RPI2241_rna_seq.fa")
protein_sequences = load_fasta("/content/RPI2241_protein_seq.fa")

# Generate all possible k-mers
def generate_kmers(k, alphabet):
    if k == 0:
        return ['']
    kmers = []
    for sub_kmer in generate_kmers(k - 1, alphabet):
        for letter in alphabet:
            kmers.append(sub_kmer + letter)
    return kmers

# Define 7-letter reduced alphabet groups according to their dipole moments and the volume of their side chains.
reduced_alphabet_groups = {
    'A': 'A', 'G': 'A', 'V': 'A',       # Group A
    'I': 'B', 'L': 'B', 'F': 'B', 'P': 'B', # Group B
    'Y': 'C', 'M': 'C', 'T': 'C', 'S': 'C', # Group C
    'H': 'D', 'N': 'D', 'Q': 'D', 'W': 'D', # Group D
    'R': 'E', 'K': 'E',                   # Group E
    'D': 'F', 'E': 'F',                   # Group F
    'C': 'G'                              # Group G
}

# Ensure that the reduced alphabet includes all necessary letters
protein_alphabet = list('ACDEFGHIKLMNPQRSTVWY')
reduced_alphabet = list(set(reduced_alphabet_groups.values()))

rna_alphabet = ['A', 'C', 'G', 'U']
all_rna_kmers = generate_kmers(4, rna_alphabet)
all_reduced_protein_kmers = generate_kmers(3, reduced_alphabet)

# Extract k-mer Features
def extract_kmer_features(sequence, k, all_kmers):
    kmer_counts = defaultdict(int)
    for i in range(len(sequence) - k + 1):
        kmer = sequence[i:i + k]
        kmer_counts[kmer] += 1
    total_kmers = sum(kmer_counts.values())
    feature_vector = [kmer_counts[kmer] / total_kmers for kmer in all_kmers]
    return feature_vector

def reduce_alphabet(protein_seq, mapping):
    reduced_seq = ''.join([mapping[aa] for aa in protein_seq if aa in mapping])
    return reduced_seq

# Normalize the Features (Min-Max normalization)
def normalize_features_min_max(features):
    scaler = MinMaxScaler()
    normalized_features = scaler.fit_transform(features)
    return normalized_features

# Combine Features and Labels
pairs_df = pd.read_csv("/content/RPI2241_pairs.txt", sep="\t", header=None)
pairs_df.columns = ["Protein", "RNA", "Label"]

all_features = []
for index, row in pairs_df.iterrows():
    protein_id, rna_id, label = row["Protein"], row["RNA"], row["Label"]
    if protein_id not in protein_sequences or rna_id not in rna_sequences:
        continue

    protein_seq = protein_sequences[protein_id]
    rna_seq = rna_sequences[rna_id]

    reduced_protein_seq = reduce_alphabet(protein_seq, reduced_alphabet_groups)

    protein_kmer_features = extract_kmer_features(reduced_protein_seq, 3, all_reduced_protein_kmers)
    rna_kmer_features = extract_kmer_features(rna_seq, 4, all_rna_kmers)

    # Combine features
    combined_features = protein_kmer_features + rna_kmer_features
    combined_features.append(label)

    all_features.append(combined_features)

# Normalize the feature vectors
features = np.array(all_features)
normalized_features = normalize_features_min_max(features[:, :-1])

# Combine normalized features with labels
final_features = np.hstack((normalized_features, features[:, -1].reshape(-1, 1)))

# Save to CSV
output_df = pd.DataFrame(final_features)
output_df.to_csv("normalized_features_min_max.csv", index=False, header=False)

print("Feature extraction and normalization completed. Saved to 'normalized_features_min_max.csv'.")


