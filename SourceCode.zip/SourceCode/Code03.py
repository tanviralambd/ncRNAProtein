
# Code 3: Train Naive Bayes classifier on raw features
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, matthews_corrcoef
)

# Load the normalized features and labels
data = pd.read_csv("/content/normalized_features_min_max (NPInter 10412).csv", header=None)
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

# 5-fold cross-validation setup
kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
accuracy_scores, precision_scores, recall_scores, f1_scores, roc_auc_scores, specificity_scores, mcc_scores = [], [], [], [], [], [], []

for train_index, test_index in kf.split(X, y):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # Train Naive Bayes on raw features
    nb_raw = GaussianNB()
    nb_raw.fit(X_train, y_train)
    nb_raw_probs = nb_raw.predict_proba(X_test)[:, 1]  # Use probabilities for the positive class
    nb_raw_preds = nb_raw.predict(X_test)

    # Evaluate the model
    accuracy_scores.append(accuracy_score(y_test, nb_raw_preds))
    precision_scores.append(precision_score(y_test, nb_raw_preds))
    recall_scores.append(recall_score(y_test, nb_raw_preds))
    f1_scores.append(f1_score(y_test, nb_raw_preds))
    roc_auc_scores.append(roc_auc_score(y_test, nb_raw_probs))  # Use probabilities here

    tn, fp, fn, tp = confusion_matrix(y_test, nb_raw_preds).ravel()
    specificity = tn / (tn + fp) if (tn + fp) != 0 else 0
    specificity_scores.append(specificity)
    mcc_scores.append(matthews_corrcoef(y_test, nb_raw_preds))

# Print average scores
print(f"Average Accuracy: {np.mean(accuracy_scores):.4f}")
print(f"Average Precision: {np.mean(precision_scores):.4f}")
print(f"Average Recall: {np.mean(recall_scores):.4f}")
print(f"Average F1 Score: {np.mean(f1_scores):.4f}")
print(f"Average ROC AUC: {np.mean(roc_auc_scores):.4f}")
print(f"Average Specificity: {np.mean(specificity_scores):.4f}")
print(f"Average MCC: {np.mean(mcc_scores):.4f}")



