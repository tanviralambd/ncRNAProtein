

# Code 6:  Con (256-128-64) “Performance of SDA on one network architecture”
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold
from keras.models import Model, Sequential
from keras.layers import Input, Dense, Dropout, GaussianNoise
from keras import regularizers
from keras.optimizers import Adam, SGD
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, matthews_corrcoef
from tensorflow.keras.layers import BatchNormalization
# Load the normalized features and labels
data = pd.read_csv("/content/normalized_features_min_max(RPI_369).csv", header=None)
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

# Function to build and train a stacked denoising autoencoder
def build_stacked_denoising_autoencoder(input_dim):
    input_layer = Input(shape=(input_dim,))
    noisy_input = GaussianNoise(0.1)(input_layer)  # Add Gaussian noise with a standard deviation of 0.1
    encoder = Dense(256, activation="relu", activity_regularizer=regularizers.l1(10e-5))(noisy_input)
    encoder = Dense(128, activation="relu")(encoder)
    encoder = Dense(64, activation="relu")(encoder)
    decoder = Dense(256, activation="relu")(encoder)
    decoder = Dense(128, activation="relu")(decoder)
    decoder = Dense(64, activation="relu")(decoder)
    decoder = Dense(input_dim, activation="sigmoid")(decoder)  # Output layer
    autoencoder = Model(inputs=input_layer, outputs=decoder)
    autoencoder.compile(optimizer=Adam(), loss='mean_squared_error')
    return autoencoder

# 5-fold cross-validation setup
kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
accuracy_scores, precision_scores, recall_scores, f1_scores, roc_auc_scores, specificity_scores, mcc_scores = [], [], [], [], [], [], []

for train_index, test_index in kf.split(X, y):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # Train the stacked denoising autoencoder
    autoencoder = build_stacked_denoising_autoencoder(X_train.shape[1])
    autoencoder.fit(X_train, X_train, epochs=100, batch_size=100, shuffle=True)

    # Extract high-level features
    encoder_model = Model(inputs=autoencoder.input, outputs=autoencoder.layers[6].output)  # Using deeper layer
    high_level_features_train = encoder_model.predict(X_train)
    high_level_features_test = encoder_model.predict(X_test)

    # Train RandomForest on SDA features
    rf_sda = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_sda.fit(high_level_features_train, y_train)
    rf_sda_probs_train = rf_sda.predict_proba(high_level_features_train)[:, 1]
    rf_sda_probs_test = rf_sda.predict_proba(high_level_features_test)[:, 1]

    # Fine-tune the high-level features using labeled data

    # Fine-tuning on high-level features
    input_tensor = Input(shape=(high_level_features_train.shape[1],))
    x = Dense(256, activation="relu")(input_tensor)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    x = Dense(128, activation="relu")(x)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    x = Dense(64, activation="relu", name="dense_64_layer")(x)  # Named layer for extraction
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    output_tensor = Dense(1, activation="sigmoid")(x)

    fine_tuned_model = Model(inputs=input_tensor, outputs=output_tensor)
    fine_tuned_model.compile(optimizer=SGD(learning_rate=0.01, momentum=0.9), loss='binary_crossentropy', metrics=['accuracy'])
    fine_tuned_model.fit(high_level_features_train, y_train, epochs=100, batch_size=100, shuffle=True, validation_split=0.1)

    # Force model to process at least one sample before extracting features
    _ = fine_tuned_model.predict(high_level_features_train[:1])

    # Extract fine-tuned features (64D layer)
    fine_tuned_feature_extractor = Model(inputs=fine_tuned_model.input, outputs=fine_tuned_model.get_layer(name="dense_64_layer").output)
    fine_tuned_features_train = fine_tuned_feature_extractor.predict(high_level_features_train)
    fine_tuned_features_test = fine_tuned_feature_extractor.predict(high_level_features_test)

    # Train RandomForest on raw k-mer features
    rf_raw = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_raw.fit(X_train, y_train)
    rf_raw_probs_train = rf_raw.predict_proba(X_train)[:, 1]
    rf_raw_probs_test = rf_raw.predict_proba(X_test)[:, 1]

    # Train RandomForest on fine-tuned SDA features
    rf_fine_tuned = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_fine_tuned.fit(fine_tuned_features_train, y_train)
    rf_fine_tuned_probs_train = rf_fine_tuned.predict_proba(fine_tuned_features_train)[:, 1]
    rf_fine_tuned_probs_test = rf_fine_tuned.predict_proba(fine_tuned_features_test)[:, 1]

    # Combine features for XGBoost
    combined_features_xgb_train = np.vstack((rf_raw_probs_train, rf_fine_tuned_probs_train, rf_sda_probs_train)).T
    combined_features_xgb_test = np.vstack((rf_raw_probs_test, rf_fine_tuned_probs_test, rf_sda_probs_test)).T

# Train XGBoost on combined features using training labels
    xgb = XGBClassifier(
        n_estimators=100, max_depth=6, learning_rate=0.01, subsample=0.8,
        colsample_bytree=0.8, gamma=0.1, lambda_=1.0, alpha=0.5, eval_metric='logloss'
    )

    # Train XGBoost on combined features using training labels
    xgb = XGBClassifier(n_estimators=100, eval_metric='logloss')
    xgb.fit(combined_features_xgb_train, y_train)

    # Make predictions on the test set
    final_probs = xgb.predict_proba(combined_features_xgb_test)[:, 1]
    final_predictions = xgb.predict(combined_features_xgb_test)

    # Evaluate the model
    accuracy_scores.append(accuracy_score(y_test, final_predictions))
    precision_scores.append(precision_score(y_test, final_predictions))
    recall_scores.append(recall_score(y_test, final_predictions))
    f1_scores.append(f1_score(y_test, final_predictions))
    roc_auc_scores.append(roc_auc_score(y_test, final_probs))

    tn, fp, fn, tp = confusion_matrix(y_test, final_predictions).ravel()
    specificity = tn / (tn + fp) if (tn + fp) != 0 else 0
    specificity_scores.append(specificity)
    mcc_scores.append(matthews_corrcoef(y_test, final_predictions))

# Print average scores
print("Performance using XGBoost on combined RandomForest predictions:")
print(f"Average Accuracy: {np.mean(accuracy_scores):.4f}")
print(f"Average Precision: {np.mean(precision_scores):.4f}")
print(f"Average Recall: {np.mean(recall_scores):.4f}")
print(f"Average F1 Score: {np.mean(f1_scores):.4f}")
print(f"Average ROC AUC: {np.mean(roc_auc_scores):.4f}")
print(f"Average Specificity: {np.mean(specificity_scores):.4f}")
print(f"Average MCC: {np.mean(mcc_scores):.4f}")




