
# Code 8: “Performance comparison among our proposed methos and previous methods”
import numpy as np
import matplotlib.pyplot as plt

# Accuracy results for different models
datasets = ['RPI369', 'RPI488', 'RPI1807', 'RPI2241', 'NPInter']
rpi_sda_rf_xgboost_accuracy = [0.6748, 0.8873, 0.9685, 0.8318, 0.9442]
ipminer_accuracy = [0.752, 0.891, 0.986, 0.824, 0.952]
rpiter_accuracy = [0.728, 0.893, 0.968, 0.890, 0.955]
rpi_san_accuracy = [0, 0.897, 0.961, 0.9077, 0]  # Ensure no None values
bgfe_accuracy = [0, 0.8868, 0.9600, 0.9130, 0]

# Position of the bars on the x-axis
x = np.arange(len(datasets))

# Width of a bar
width = 0.15

fig, ax = plt.subplots(figsize=(12, 6))

# Create bars for each model
rects1 = ax.bar(x - 2 * width, rpi_sda_rf_xgboost_accuracy, width, label='RPI_SDA-XGBoost', color='orange')
rects2 = ax.bar(x - width, ipminer_accuracy, width, label='IPMiner', color='green')
rects3 = ax.bar(x, rpiter_accuracy, width, label='RPITER', color='blue')
rects4 = ax.bar(x + width, rpi_san_accuracy, width, label='RPI-SAN', color='purple')
rects5 = ax.bar(x + 2 * width, bgfe_accuracy, width, label='BGFE', color='red')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_xlabel('Datasets')
ax.set_ylabel('Accuracy')
ax.set_title('Performance comparison among RPI_SDA_XGBoost and previous DL. RPI methods')
ax.set_xticks(x)
ax.set_xticklabels(datasets)

# Adjust the legend to be small and in the upper left
ax.legend(ncol=1, loc='upper left', fontsize='x-small')

fig.tight_layout()

plt.show()

