
# Code 7: Our proposed method “SDA_RF-XGBoost :sep(256-128-64)” 
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, matthews_corrcoef, roc_curve, auc
)
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Input, Dense, Dropout, GaussianNoise, concatenate
from tensorflow.keras.optimizers import Adam, SGD
from xgboost import XGBClassifier
from tensorflow.keras.layers import BatchNormalization
# Load the normalized features and labels
data = pd.read_csv("/content/normalized_features_min_max (RPI_488).csv", header=None)
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

# Split features into protein and RNA
protein_features = X[:, :343]  # Assuming 343 protein features
rna_features = X[:, 256:]      # Assuming 256 RNA features

# Function to build and train a stacked denoising autoencoder
def build_stacked_denoising_autoencoder(protein_input_dim, rna_input_dim):
    # Protein sub-network
    protein_input = Input(shape=(protein_input_dim,))
    noisy_protein_input = GaussianNoise(0.1)(protein_input)
    protein_encoder = Dense(256, activation="relu")(noisy_protein_input)
    protein_encoder = Dense(128, activation="relu")(protein_encoder)
    protein_encoder = Dense(64, activation="relu")(protein_encoder)

    # RNA sub-network
    rna_input = Input(shape=(rna_input_dim,))
    noisy_rna_input = GaussianNoise(0.1)(rna_input)
    rna_encoder = Dense(256, activation="relu")(noisy_rna_input)
    rna_encoder = Dense(128, activation="relu")(rna_encoder)
    rna_encoder = Dense(64, activation="relu")(rna_encoder)

    # Merge sub-networks
    merged = concatenate([protein_encoder, rna_encoder]) #10 layer
    decoder = Dense(128, activation="relu")(merged)
    decoder = Dense(256, activation="relu")(decoder)
    decoder = Dense(protein_input_dim + rna_input_dim, activation="sigmoid")(decoder)

    autoencoder = Model(inputs=[protein_input, rna_input], outputs=decoder)
    autoencoder.compile(optimizer=Adam(), loss='mean_squared_error')
    return autoencoder

# Initialize Stratified K-Fold
kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Initialize metrics storage
metrics = {
    'raw': [],
    'before_ft': [],
    'after_ft': [],
    'xgb': []
}

# Prepare to plot ROC curves
mean_fpr = np.linspace(0, 1, 100)
tprs_raw, tprs_before_ft, tprs_after_ft, tprs_xgb = [], [], [], []
aucs_raw, aucs_before_ft, aucs_after_ft, aucs_xgb = [], [], [], []

for train_index, test_index in kf.split(X, y):
    X_train_protein, X_test_protein = protein_features[train_index], protein_features[test_index]
    X_train_rna, X_test_rna = rna_features[train_index], rna_features[test_index]
    y_train, y_test = y[train_index], y[test_index]

    # Train the stacked denoising autoencoder
    autoencoder = build_stacked_denoising_autoencoder(X_train_protein.shape[1], X_train_rna.shape[1])
    autoencoder.fit([X_train_protein, X_train_rna], np.hstack([X_train_protein, X_train_rna]), epochs=100, batch_size=100, shuffle=True)

    # Extract high-level features
    encoder_model = Model(inputs=autoencoder.input, outputs=autoencoder.layers[10].output)
    high_level_features_train = encoder_model.predict([X_train_protein, X_train_rna])
    high_level_features_test = encoder_model.predict([X_test_protein, X_test_rna])

    # Train RandomForest on raw combined features
    rf_raw = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_raw.fit(np.hstack((X_train_protein, X_train_rna)), y_train)
    rf_raw_probs_train = rf_raw.predict_proba(np.hstack((X_train_protein, X_train_rna)))[:, 1]
    rf_raw_probs_test = rf_raw.predict_proba(np.hstack((X_test_protein, X_test_rna)))[:, 1]

    # Calculate metrics for RandomForest on raw features
    acc_raw = accuracy_score(y_test, rf_raw.predict(np.hstack((X_test_protein, X_test_rna))))
    prec_raw = precision_score(y_test, rf_raw.predict(np.hstack((X_test_protein, X_test_rna))))
    rec_raw = recall_score(y_test, rf_raw.predict(np.hstack((X_test_protein, X_test_rna))))
    f1_raw = f1_score(y_test, rf_raw.predict(np.hstack((X_test_protein, X_test_rna))))
    mcc_raw = matthews_corrcoef(y_test, rf_raw.predict(np.hstack((X_test_protein, X_test_rna))))
    auc_raw = roc_auc_score(y_test, rf_raw_probs_test)
    tn, fp, fn, tp = confusion_matrix(y_test, rf_raw.predict(np.hstack((X_test_protein, X_test_rna)))).ravel()
    specificity_raw = tn / (tn + fp) if (tn + fp) != 0 else 0

    metrics['raw'].append((acc_raw, prec_raw, rec_raw, f1_raw, mcc_raw, auc_raw, specificity_raw))

    # ROC for RandomForest on raw features
    fpr_rf_raw, tpr_rf_raw, _ = roc_curve(y_test, rf_raw_probs_test)
    aucs_raw.append(auc(fpr_rf_raw, tpr_rf_raw))
    tprs_raw.append(np.interp(mean_fpr, fpr_rf_raw, tpr_rf_raw))

    # Train RandomForest on SDA features before fine-tuning
    rf_before_ft = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_before_ft.fit(high_level_features_train, y_train)
    rf_before_ft_probs_train = rf_before_ft.predict_proba(high_level_features_train)[:, 1]
    rf_before_ft_probs_test = rf_before_ft.predict_proba(high_level_features_test)[:, 1]

    # Calculate metrics for RandomForest before fine-tuning
    acc_before_ft = accuracy_score(y_test, rf_before_ft.predict(high_level_features_test))
    prec_before_ft = precision_score(y_test, rf_before_ft.predict(high_level_features_test))
    rec_before_ft = recall_score(y_test, rf_before_ft.predict(high_level_features_test))
    f1_before_ft = f1_score(y_test, rf_before_ft.predict(high_level_features_test))
    mcc_before_ft = matthews_corrcoef(y_test, rf_before_ft.predict(high_level_features_test))
    auc_before_ft = roc_auc_score(y_test, rf_before_ft_probs_test)
    tn, fp, fn, tp = confusion_matrix(y_test, rf_before_ft.predict(high_level_features_test)).ravel()
    specificity_before_ft = tn / (tn + fp) if (tn + fp) != 0 else 0

    metrics['before_ft'].append((acc_before_ft, prec_before_ft, rec_before_ft, f1_before_ft, mcc_before_ft, auc_before_ft, specificity_before_ft))

    # ROC for RandomForest on SDA features before fine-tuning
    fpr_rf_before_ft, tpr_rf_before_ft, _ = roc_curve(y_test, rf_before_ft_probs_test)
    aucs_before_ft.append(auc(fpr_rf_before_ft, tpr_rf_before_ft))
    tprs_before_ft.append(np.interp(mean_fpr, fpr_rf_before_ft, tpr_rf_before_ft))
    #  Fine-tuning on high-level features
    input_tensor = Input(shape=(high_level_features_train.shape[1],))
    x = Dense(256, activation="relu")(input_tensor)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    x = Dense(128, activation="relu")(x)
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    x = Dense(64, activation="relu", name="dense_64_layer")(x)  # Named layer for extraction
    x = BatchNormalization()(x)
    x = Dropout(0.5)(x)
    output_tensor = Dense(1, activation="sigmoid")(x)

    fine_tuned_model = Model(inputs=input_tensor, outputs=output_tensor)
    fine_tuned_model.compile(optimizer=SGD(learning_rate=0.01, momentum=0.9), loss='binary_crossentropy', metrics=['accuracy'])
    fine_tuned_model.fit(high_level_features_train, y_train, epochs=100, batch_size=100, shuffle=True, validation_split=0.1)

    # Force model to process at least one sample before extracting features
    _ = fine_tuned_model.predict(high_level_features_train[:1])

    # Extract fine-tuned features (64D layer)
    fine_tuned_feature_extractor = Model(inputs=fine_tuned_model.input, outputs=fine_tuned_model.get_layer(name="dense_64_layer").output)
    fine_tuned_features_train = fine_tuned_feature_extractor.predict(high_level_features_train)
    fine_tuned_features_test = fine_tuned_feature_extractor.predict(high_level_features_test)

     # Train RandomForest on fine-tuned SDA features
    rf_after_ft = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_after_ft.fit(fine_tuned_features_train, y_train)
    rf_after_ft_probs_train = rf_after_ft.predict_proba(fine_tuned_features_train)[:, 1]
    rf_after_ft_probs_test = rf_after_ft.predict_proba(fine_tuned_features_test)[:, 1]

    # Calculate metrics for RandomForest after fine-tuning
    acc_after_ft = accuracy_score(y_test, rf_after_ft.predict(fine_tuned_features_test))
    prec_after_ft = precision_score(y_test, rf_after_ft.predict(fine_tuned_features_test))
    rec_after_ft = recall_score(y_test, rf_after_ft.predict(fine_tuned_features_test))
    f1_after_ft = f1_score(y_test, rf_after_ft.predict(fine_tuned_features_test))
    mcc_after_ft = matthews_corrcoef(y_test, rf_after_ft.predict(fine_tuned_features_test))
    auc_after_ft = roc_auc_score(y_test, rf_after_ft_probs_test)
    tn, fp, fn, tp = confusion_matrix(y_test, rf_after_ft.predict(fine_tuned_features_test)).ravel()
    specificity_after_ft = tn / (tn + fp) if (tn + fp) != 0 else 0

    metrics['after_ft'].append((acc_after_ft, prec_after_ft, rec_after_ft, f1_after_ft, mcc_after_ft, auc_after_ft, specificity_after_ft))

    # ROC for RandomForest on fine-tuned SDA features
    fpr_rf_after_ft, tpr_rf_after_ft, _ = roc_curve(y_test, rf_after_ft_probs_test)
    aucs_after_ft.append(auc(fpr_rf_after_ft, tpr_rf_after_ft))
    tprs_after_ft.append(np.interp(mean_fpr, fpr_rf_after_ft, tpr_rf_after_ft))

    # Combine features for XGBoost
    combined_features_xgb_train = np.vstack((rf_raw_probs_train, rf_before_ft_probs_train, rf_after_ft_probs_train)).T
    combined_features_xgb_test = np.vstack((rf_raw_probs_test, rf_before_ft_probs_test, rf_after_ft_probs_test)).T

    # Train XGBoost on combined features using training labels
    xgb = XGBClassifier(
        n_estimators=100, max_depth=6, learning_rate=0.01, subsample=0.8,
        colsample_bytree=0.8, gamma=0.1, alpha=0.5, eval_metric='logloss'
    )
    xgb.fit(combined_features_xgb_train, y_train)

    # Make predictions on the test set
    final_probs = xgb.predict_proba(combined_features_xgb_test)[:, 1]
    final_predictions = xgb.predict(combined_features_xgb_test)

    # Calculate metrics for XGBoost
    acc_xgb = accuracy_score(y_test, final_predictions)
    prec_xgb = precision_score(y_test, final_predictions)
    rec_xgb = recall_score(y_test, final_predictions)
    f1_xgb = f1_score(y_test, final_predictions)
    mcc_xgb = matthews_corrcoef(y_test, final_predictions)
    auc_xgb = roc_auc_score(y_test, final_probs)
    tn, fp, fn, tp = confusion_matrix(y_test, final_predictions).ravel()
    specificity_xgb = tn / (tn + fp) if (tn + fp) != 0 else 0

    metrics['xgb'].append((acc_xgb, prec_xgb, rec_xgb, f1_xgb, mcc_xgb, auc_xgb, specificity_xgb))

    # ROC for XGBoost
    fpr_xgb, tpr_xgb, _ = roc_curve(y_test, final_probs)
    aucs_xgb.append(auc(fpr_xgb, tpr_xgb))
    tprs_xgb.append(np.interp(mean_fpr, fpr_xgb, tpr_xgb))

# Plot ROC curves
plt.plot(mean_fpr, np.mean(tprs_raw, axis=0), color='blue', label='RF Raw (AUC = {:.4f})'.format(np.mean(aucs_raw)))
plt.plot(mean_fpr, np.mean(tprs_before_ft, axis=0), color='green', label='RF Before FT (AUC = {:.4f})'.format(np.mean(aucs_before_ft)))
plt.plot(mean_fpr, np.mean(tprs_after_ft, axis=0), color='red', label='RF After FT (AUC = {:.4f})'.format(np.mean(aucs_after_ft)))
plt.plot(mean_fpr, np.mean(tprs_xgb, axis=0), color='purple', label='XGBoost (AUC = {:.4f})'.format(np.mean(aucs_xgb)))

plt.plot([0, 1], [0, 1], 'k--', lw=2)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.show()

# Print performance metrics for each classifier
print("Performance Metrics:")
print(f"RF Raw - Accuracy: {np.mean([m[0] for m in metrics['raw']]):.4f}, Precision: {np.mean([m[1] for m in metrics['raw']]):.4f}, Recall: {np.mean([m[2] for m in metrics['raw']]):.4f}, F1 Score: {np.mean([m[3] for m in metrics['raw']]):.4f}, MCC: {np.mean([m[4] for m in metrics['raw']]):.4f}, AUC: {np.mean([m[5] for m in metrics['raw']]):.4f}, Specificity: {np.mean([m[6] for m in metrics['raw']]):.4f}")
print(f"RF Before FT - Accuracy: {np.mean([m[0] for m in metrics['before_ft']]):.4f}, Precision: {np.mean([m[1] for m in metrics['before_ft']]):.4f}, Recall: {np.mean([m[2] for m in metrics['before_ft']]):.4f}, F1 Score: {np.mean([m[3] for m in metrics['before_ft']]):.4f}, MCC: {np.mean([m[4] for m in metrics['before_ft']]):.4f}, AUC: {np.mean([m[5] for m in metrics['before_ft']]):.4f}, Specificity: {np.mean([m[6] for m in metrics['before_ft']]):.4f}")
print(f"RF After FT - Accuracy: {np.mean([m[0] for m in metrics['after_ft']]):.4f}, Precision: {np.mean([m[1] for m in metrics['after_ft']]):.4f}, Recall: {np.mean([m[2] for m in metrics['after_ft']]):.4f}, F1 Score: {np.mean([m[3] for m in metrics['after_ft']]):.4f}, MCC: {np.mean([m[4] for m in metrics['after_ft']]):.4f}, AUC: {np.mean([m[5] for m in metrics['after_ft']]):.4f}, Specificity: {np.mean([m[6] for m in metrics['after_ft']]):.4f}")
print(f"XGBoost - Accuracy: {np.mean([m[0] for m in metrics['xgb']]):.4f}, Precision: {np.mean([m[1] for m in metrics['xgb']]):.4f}, Recall: {np.mean([m[2] for m in metrics['xgb']]):.4f}, F1 Score: {np.mean([m[3] for m in metrics['xgb']]):.4f}, MCC: {np.mean([m[4] for m in metrics['xgb']]):.4f}, AUC: {np.mean([m[5] for m in metrics['xgb']]):.4f}, Specificity: {np.mean([m[6] for m in metrics['xgb']]):.4f}")


