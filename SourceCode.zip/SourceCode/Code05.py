
# Code 5: Mathplot for performance comparison among different basic prediction models RF, XGBoost, NB
import numpy as np
import matplotlib.pyplot as plt

# Dummy data for accuracy results
datasets = ['RPI369', 'RPI488', 'RPI1807', 'RPI2241', 'NPInter']
nb_accuracy = [0.367, 0.619, 0.673, 0.631, 0.786]
rf_accuracy = [0.598, 0.880, 0.960, 0.825, 0.943]
xgboost_accuracy = [0.619, 0.869, 0.968, 0.834, 0.942]

# Position of the bars on the x-axis
x = np.arange(len(datasets))

# Width of a bar
width = 0.25

fig, ax = plt.subplots()

# Create bars for each model
rects1 = ax.bar(x - width, nb_accuracy, width, label='Naive Bayes', color='orange')
rects2 = ax.bar(x, rf_accuracy, width, label='Random Forest', color='green')
rects3 = ax.bar(x + width, xgboost_accuracy, width, label='XGBoost', color='blue')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_xlabel('Datasets')
ax.set_ylabel('Accuracy')
ax.set_title('Performance comparison among different basic prediction models')
ax.set_xticks(x)
ax.set_xticklabels(datasets)
ax.legend(fontsize='small')

fig.tight_layout()

plt.show()


